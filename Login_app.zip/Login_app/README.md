# Ionic 3 TodoApp

Code for tutorial ionic 3 todo app

## Installation

Clone or download the repo and then run `npm install` command.

## Screenshot

![Screenshot](https://raw.githubusercontent.com/sarfraznawaz2005/ionictodoapp/master/screen.png)